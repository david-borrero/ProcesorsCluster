var searchData=
[
  ['baja_5fproceso_5fprocesador_11',['baja_proceso_procesador',['../classCluster.html#a8912d7d74908684c6c20408a5d449b87',1,'Cluster']]],
  ['buscar_5fprocesador_12',['buscar_procesador',['../classCluster.html#ae27a6b4e8aff1b9d41ddbcf9a176dc6a',1,'Cluster']]],
  ['busqueda_13',['busqueda',['../classCluster.html#a0507308c421b17da5d5e6db1473e16a7',1,'Cluster']]]
];
