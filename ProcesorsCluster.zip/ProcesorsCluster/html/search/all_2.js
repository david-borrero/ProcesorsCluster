var searchData=
[
  ['cluster_14',['Cluster',['../classCluster.html',1,'Cluster'],['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster::Cluster()']]],
  ['cluster_2ecc_15',['Cluster.cc',['../Cluster_8cc.html',1,'']]],
  ['cluster_2ehh_16',['Cluster.hh',['../Cluster_8hh.html',1,'']]],
  ['colocados_17',['colocados',['../structAreaProcesosPendientes_1_1Prioridad.html#a212ba7fc996b438ec791825895d061eb',1,'AreaProcesosPendientes::Prioridad']]],
  ['compactar_5fmemoria_18',['compactar_memoria',['../classProcesador.html#a06b0b1c913b359a1bc6c920120dd0e66',1,'Procesador']]],
  ['compactar_5fmemoria_5fcluster_19',['compactar_memoria_cluster',['../classCluster.html#a7b9ae511df4a6465f4e191df6564fd77',1,'Cluster']]],
  ['compactar_5fmemoria_5fprocesador_20',['compactar_memoria_procesador',['../classCluster.html#aa52e4b5f1e9306d2c9d483b0e6db1459',1,'Cluster']]],
  ['configurar_5fcluster_21',['configurar_cluster',['../classCluster.html#a84f9daea57e2773ab5766ef82d2a1def',1,'Cluster']]],
  ['consultar_5fid_22',['consultar_id',['../classProceso.html#a33b52579d6ee93986d33341bacc86521',1,'Proceso']]],
  ['consultar_5fmemoria_23',['consultar_memoria',['../classProceso.html#a55976a19b8d909276c62e8be10036df5',1,'Proceso']]],
  ['consultar_5ftiempo_24',['consultar_tiempo',['../classProceso.html#a4816bee1b97d41126160494109f84c42',1,'Proceso']]]
];
