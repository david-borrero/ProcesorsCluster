var searchData=
[
  ['elimina_5fproceso_25',['elimina_proceso',['../classProcesador.html#a7188aa887f41f2edea67308d32459ab7',1,'Procesador']]],
  ['eliminar_5fprioridad_26',['eliminar_prioridad',['../classAreaProcesosPendientes.html#a45d7ac03861801de8aec17c5c17a7b2d',1,'AreaProcesosPendientes']]],
  ['enviar_5fprocesos_5fcluster_27',['enviar_procesos_cluster',['../classAreaProcesosPendientes.html#a15b197781eafb10c25d25501e647ed9a',1,'AreaProcesosPendientes']]],
  ['escribir_28',['escribir',['../classProcesador.html#a555c4158255a7de97a578d0c0661360a',1,'Procesador::escribir()'],['../classProceso.html#a1c038ea4cc370e4bbc7b8d309d5da708',1,'Proceso::escribir()']]],
  ['espacio_29',['espacio',['../classProcesador.html#a4d0fa8e043baa303db43ca867ac5600e',1,'Procesador']]],
  ['espacio_5ftotal_30',['espacio_total',['../classProcesador.html#ad40c31687bfe9422ae0616279c3dd7ea',1,'Procesador']]],
  ['existe_5fproceso_31',['existe_proceso',['../classAreaProcesosPendientes.html#aa9de2f8878eeba9f31a6e452184b2c00',1,'AreaProcesosPendientes::existe_proceso()'],['../classProcesador.html#a4844bf7029cb81912cb8a9c5a3664647',1,'Procesador::existe_proceso()']]]
];
