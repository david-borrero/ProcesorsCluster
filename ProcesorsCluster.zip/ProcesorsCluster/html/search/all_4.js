var searchData=
[
  ['hueco_32',['hueco',['../classProcesador.html#a36846cf14afc694d279de67e23a62fd1',1,'Procesador']]],
  ['hueco_5fajustado_33',['hueco_ajustado',['../classProcesador.html#aec60715cda247b1da85799a32ad24c8b',1,'Procesador']]]
];
