var searchData=
[
  ['i_5fconfigurar_5fcluster_34',['i_configurar_cluster',['../classCluster.html#a1d5f411b5b932cb0155236b414f38d58',1,'Cluster']]],
  ['i_5fimprimir_35',['i_imprimir',['../classCluster.html#a7654e1110b7a0a7f1c240a304de744c7',1,'Cluster']]],
  ['i_5fmodificar_36',['i_modificar',['../classCluster.html#afce7f6c6127567d7d27e2c0b2dabc627',1,'Cluster']]],
  ['id_37',['id',['../classProceso.html#aedb36cca995b8b23d2e3d3739d30b216',1,'Proceso']]],
  ['imprimir_38',['imprimir',['../classAreaProcesosPendientes.html#a830bf3c618dcca6ec1297f15ab3f97a9',1,'AreaProcesosPendientes::imprimir()'],['../classCluster.html#af34d03b69038e2fab647d7d88ca31e95',1,'Cluster::imprimir()']]],
  ['imprimir_5fprioridad_39',['imprimir_prioridad',['../classAreaProcesosPendientes.html#ad4b99fb852989da0d0fe7d477ef3a1e4',1,'AreaProcesosPendientes']]],
  ['imprimir_5fprocesador_40',['imprimir_procesador',['../classCluster.html#af206c5212d8aac84d9f0f00a5be1b3c5',1,'Cluster']]],
  ['imprimir_5fprocesadores_41',['imprimir_procesadores',['../classCluster.html#afc3924fd1f4643746ec3757c7777d732',1,'Cluster']]]
];
