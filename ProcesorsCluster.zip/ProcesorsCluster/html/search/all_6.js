var searchData=
[
  ['l_42',['l',['../structAreaProcesosPendientes_1_1Prioridad.html#a40b7d2666643de8998f99465a068ff3c',1,'AreaProcesosPendientes::Prioridad']]],
  ['leer_43',['leer',['../classAreaProcesosPendientes.html#a5f180b8fec95cf66e3c7dce88c9bb9bd',1,'AreaProcesosPendientes::leer()'],['../classProcesador.html#ac104960814ba918ba113ed9d58bca271',1,'Procesador::leer()'],['../classProceso.html#ad133f53bba77755f779ef63b6e529cdb',1,'Proceso::leer()']]]
];
