var searchData=
[
  ['main_44',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['memoria_45',['memoria',['../classProcesador.html#af68811026d52327bbe7ff365f9dadf4a',1,'Procesador']]],
  ['memoria_5flibre_46',['memoria_libre',['../classProcesador.html#ae9234c9557d45ba1a7c02c83617d250d',1,'Procesador']]],
  ['modificar_47',['modificar',['../classCluster.html#a08c10b20283a025f2ce3941e7f7cc3c9',1,'Cluster']]]
];
