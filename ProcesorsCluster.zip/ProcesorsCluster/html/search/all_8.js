var searchData=
[
  ['n_5fmemoria_48',['n_memoria',['../classProceso.html#ae886156dd995d5f36a8082fe9c787338',1,'Proceso']]]
];
