var searchData=
[
  ['tiempo_62',['tiempo',['../classProceso.html#a23541aa8fe702c686a760c378a1b00d2',1,'Proceso']]],
  ['tiene_5fprocesos_63',['tiene_procesos',['../classAreaProcesosPendientes.html#a0d2bce421528984927e3ebc2ef7559fd',1,'AreaProcesosPendientes::tiene_procesos()'],['../classProcesador.html#af43db3ddfe98258796650e07a8bec6e9',1,'Procesador::tiene_procesos()']]]
];
