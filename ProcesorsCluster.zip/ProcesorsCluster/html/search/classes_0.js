var searchData=
[
  ['areaprocesospendientes_64',['AreaProcesosPendientes',['../classAreaProcesosPendientes.html',1,'']]]
];
