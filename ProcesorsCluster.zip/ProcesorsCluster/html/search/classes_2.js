var searchData=
[
  ['prioridad_66',['Prioridad',['../structAreaProcesosPendientes_1_1Prioridad.html',1,'AreaProcesosPendientes']]],
  ['procesador_67',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_68',['Proceso',['../classProceso.html',1,'']]]
];
