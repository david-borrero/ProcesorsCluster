var searchData=
[
  ['alta_5fproceso_5fprocesador_78',['alta_proceso_procesador',['../classCluster.html#afd82263edebc9d5c57041c3fd09f1847',1,'Cluster']]],
  ['anadir_5fprioridad_79',['anadir_prioridad',['../classAreaProcesosPendientes.html#a4437f1f904d5fa341ce68d7c2d395d6a',1,'AreaProcesosPendientes']]],
  ['anadir_5fproceso_80',['anadir_proceso',['../classAreaProcesosPendientes.html#af70f0ec0dcca4a069bb526e8b75a6abb',1,'AreaProcesosPendientes::anadir_proceso()'],['../classProcesador.html#a6037f60c9944e604fcb8ebe352b04f0b',1,'Procesador::anadir_proceso()']]],
  ['areaprocesospendientes_81',['AreaProcesosPendientes',['../classAreaProcesosPendientes.html#ac01fee35894a81ee68b73c533893148f',1,'AreaProcesosPendientes']]],
  ['arreglar_82',['arreglar',['../classProcesador.html#a733d637b3d5cfa4e1fbf4f8a5db54264',1,'Procesador']]],
  ['avanzar_5ftiempo_83',['avanzar_tiempo',['../classProcesador.html#a94b93c1fc62bfcacfd1488e76e4b9f65',1,'Procesador::avanzar_tiempo()'],['../classProceso.html#a9422c4ae9614c38844d15169523cd9fc',1,'Proceso::avanzar_tiempo()']]],
  ['avanzar_5ftiempo_5fprocesadores_84',['avanzar_tiempo_procesadores',['../classCluster.html#a38e3239442a942c22090a12659fd9561',1,'Cluster']]]
];
