var searchData=
[
  ['hueco_5fajustado_101',['hueco_ajustado',['../classProcesador.html#aec60715cda247b1da85799a32ad24c8b',1,'Procesador']]]
];
