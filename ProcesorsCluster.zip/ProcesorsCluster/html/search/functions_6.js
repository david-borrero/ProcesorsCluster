var searchData=
[
  ['leer_109',['leer',['../classAreaProcesosPendientes.html#a5f180b8fec95cf66e3c7dce88c9bb9bd',1,'AreaProcesosPendientes::leer()'],['../classProcesador.html#ac104960814ba918ba113ed9d58bca271',1,'Procesador::leer()'],['../classProceso.html#ad133f53bba77755f779ef63b6e529cdb',1,'Proceso::leer()']]]
];
