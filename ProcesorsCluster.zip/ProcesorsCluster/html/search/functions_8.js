var searchData=
[
  ['procesador_113',['Procesador',['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador']]],
  ['proceso_114',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso']]],
  ['puede_5fcolocarse_115',['puede_colocarse',['../classProcesador.html#a87e588ab3b6dde37395acd89adf105c3',1,'Procesador']]]
];
