var searchData=
[
  ['tiene_5fprocesos_116',['tiene_procesos',['../classAreaProcesosPendientes.html#a0d2bce421528984927e3ebc2ef7559fd',1,'AreaProcesosPendientes::tiene_procesos()'],['../classProcesador.html#af43db3ddfe98258796650e07a8bec6e9',1,'Procesador::tiene_procesos()']]]
];
