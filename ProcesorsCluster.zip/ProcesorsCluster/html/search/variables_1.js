var searchData=
[
  ['colocados_119',['colocados',['../structAreaProcesosPendientes_1_1Prioridad.html#a212ba7fc996b438ec791825895d061eb',1,'AreaProcesosPendientes::Prioridad']]]
];
