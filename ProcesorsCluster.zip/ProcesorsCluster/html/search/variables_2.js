var searchData=
[
  ['espacio_120',['espacio',['../classProcesador.html#a4d0fa8e043baa303db43ca867ac5600e',1,'Procesador']]],
  ['espacio_5ftotal_121',['espacio_total',['../classProcesador.html#ad40c31687bfe9422ae0616279c3dd7ea',1,'Procesador']]]
];
