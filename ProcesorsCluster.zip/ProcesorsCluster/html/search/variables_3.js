var searchData=
[
  ['hueco_122',['hueco',['../classProcesador.html#a36846cf14afc694d279de67e23a62fd1',1,'Procesador']]]
];
