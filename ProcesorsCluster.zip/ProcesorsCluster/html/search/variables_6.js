var searchData=
[
  ['memoria_125',['memoria',['../classProcesador.html#af68811026d52327bbe7ff365f9dadf4a',1,'Procesador']]]
];
