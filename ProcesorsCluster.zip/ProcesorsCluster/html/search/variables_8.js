var searchData=
[
  ['posicion_127',['posicion',['../classProcesador.html#a75f87b50fb0356befde02636141ea08b',1,'Procesador']]],
  ['procesadores_128',['procesadores',['../classCluster.html#a0456efea2e21cfeebda8f61669649a59',1,'Cluster']]],
  ['procesos_129',['procesos',['../structAreaProcesosPendientes_1_1Prioridad.html#ae28d869ab6d051ae947a0e48a6c17f2d',1,'AreaProcesosPendientes::Prioridad']]]
];
