var searchData=
[
  ['tiempo_131',['tiempo',['../classProceso.html#a23541aa8fe702c686a760c378a1b00d2',1,'Proceso']]]
];
